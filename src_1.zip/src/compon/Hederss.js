// import React from "react"

// const hhhs = () => {
//     return(
//         <div>
//         <header id='heder2'> 
//         <img src="https://static.insales-cdn.com/files/1/3373/16379181/original/Component_22.png" alt="" id='img1'/> 
//         <input type='text' placeholder='Поиск'/> 
//         <p id='z1'>Профиль</p> 
//         <p id='z1'>Сравнение</p> 
//         <p id='z1'>Избранное</p> 
//         <p id='z1'>Корзина</p> 
//     </header>
//     </div> 
//     )
// }
// export default hhhs;