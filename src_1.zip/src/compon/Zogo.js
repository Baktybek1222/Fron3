// import React from "react"

// const headerr = () => {
//     return(
//         <div>
//             <header id="heder1">
//                 <p id="x1">Доставка и оплата</p>
//                 <p id="x1">Пункты выдачи</p>
//                 <p id="x1">Поддержка</p>
//                 <p id="x1">+996771115059</p>
//             </header>
//         </div>
//     )
// }
// export default headerr;