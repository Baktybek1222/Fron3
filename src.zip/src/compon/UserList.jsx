import firebase from './firebase.js';  
import React, { useEffect, useState } from 'react';  
import './UserList.css'  
 
  
const UserList = () => {  
    const ref = firebase.firestore().collection('user')  
    const [data, setdata] = useState([])  
  
    function getData() {  
        ref.onSnapshot((QuerySnapshot) => {  
            const items = []  
            QuerySnapshot.forEach((doc) => {  
                items.push(doc.data())  
            })  
            setdata(items)  
        })  
    }  
  
    useEffect(() => {  
        getData()  
    }, [])  
    console.log(data);  
  
  
  
     return (  
           <div className='UsersList'>  
            {data.map((elem) => {  
                return (  
                    <div className='UserList'> 
                         <header id='heder1'>
                            
                            <p id='x1'>Доставка и оплата</p>
                            <p id='x2'>Пункты выдачи</p>
                            <p id='x3'>Поддержка</p>
                            <p id='x4'>+996771115059</p>
                            
                        </header> 
                        <header id='heder2'> 
                            <img src="https://static.insales-cdn.com/files/1/3373/16379181/original/Component_22.png" alt="" id='img1'/> 
                            <input type='text' placeholder='Поиск'/> 
                            <p id='z1'>Профиль</p> 
                            <p id='z1'>Сравнение</p> 
                            <p id='z1'>Избранное</p> 
                            <p id='z1'>Корзина</p> 
                        </header> 
                        <div id='div2'> 
                        <p id='x1'>Смартфоны и планшеты</p> 
                        <p id='x1'>Ноутбуки, планшеты и компьютеры</p>  
                        <p id='x1'>Техника для дома</p>  
                        <p id='x1'>Игры и развлечения</p>  
                        </div> 
                        <div> 
                            
                         <img src = {elem.img} id='i1'/> 
                         
                        
                         
                         <img src={elem.img1} id='i2'/> 
                        <img src={elem.img2} id='i3'/> 
                        <img src={elem.img4} id='i4'/> 
                        <img src={elem.img1} id='i5'/> 
                        <img src={elem.img6} id='i6'/> 
                        <img src={elem.img7} id='i7'/>  
                         
                            </div> 
                            <p id='p1'>Смартфоны и планшеты</p> 
                        <div id='div1'>             
                        <p>{elem.name}</p>   
                         <p>{elem.descr}</p>  
                         <p>{elem.price}</p>  
                        </div> 
                        <div id='xx1' >
                            <div>
                            <img src={elem.tel1} id='vv1' />
                            <p id='x1'>{elem.p1}</p>
                            <p id='v1211'>{elem.p2}Р</p>
                            </div>
                            <div>
                            <img src={elem.tel2} id='vv2' />
                            <p id='x1'>{elem.p3}</p>
                            <p id='v1211'>{elem.p4}Р</p>
                            </div>
                            <div>
                            <img src={elem.tel3} id='vv3'  />
                            <p id='x1'>{elem.p5}P</p>
                            <p id='v1211'>{elem.p6}Р</p>
                            </div>
                            <div>
                            <img src={elem.tel4} id='vv4' />
                            <p id='x1'>Смартфон Nokia 3.4</p>
                            <p id='v1211'>14342Р</p>
                            </div>
                            <div>
                            <img src={elem.tel5} id='vv5'/>
                            <p id='x1'>Смартфон Xiaomi Redmi 9</p>
                            <p id='v1211'>17422Р</p>
                            </div>
                            </div>
                            <div>
                                <p id='ll1'>Акции</p>
                                </div>
                            <div id='o1'>
                                <img src={elem.Ak1}/>
                                <img src={elem.Ak2}/>
                                <img src={elem.Ak3}/>
                                
                                </div>
                                <div>
                                <p id='o2'>Ноутбуки</p>
                                </div>
                                <div>
                                    </div>
                                    <img src=''/>
                    </div>  
                )  
            }  
            )}  
           </div>  
        )  
}  
  
export default UserList;