import React from "react"; 
import UserList from "./compon/UserList.jsx"; 
import headerr from "./compon/Zogo.js";
 
function App() { 
    
 
    return ( 
        // <div className='UsersList'> 
        //     {data.map((elem, index) => ( 
        //         <div className='UserList' key={index}> 
        //             <p>{elem.name}</p> 
        //             <p>{elem.descr}</p> 
        //             <p>{elem.price}</p> 
                     
        //             <button>ghbsdf</button> 
        //         </div> 
        //     ))} 
        // </div> 
        <UserList/> 
        
    ); 
} 
 
export default UserList
